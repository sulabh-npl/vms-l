<?php $__env->startSection('content'); ?>
<div class="input-group">
  <div class="form-outline">
      <div class="col-sm-4" style="margin-left: 350px;margin-right:-30px">
    <input type="search" style="width: 100%;" class="form-control" >
    <label class="form-label" style="align-item: center;" for="form1">Search</label>
    </div>
    <div class="col-sm-1">
  <button type="button" class="btn btn-primary">
    <i class="fas fa-search"></i>
  </button>
    </div>
  </div>
</div>
<ul class="list-group list-group-flush">
    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/admin/login/<?php echo e($vendor->id); ?>"><li class="list-group-item"><?php echo e($vendor->name); ?></li></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <li class="list-group-item">Dummy</li>
  <li class="list-group-item">Dummy</li>
  <li class="list-group-item">Dummy</li>
  <li class="list-group-item">Dummy</li>
  <li class="list-group-item">Dummy</li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.super-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\vendor-l\resources\views/admin/list.blade.php ENDPATH**/ ?>