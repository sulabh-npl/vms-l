<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OTP</title>
</head>
<body>
    <h1>Keep this OTP secret</h1>
    <p>Tour OTP is <b><?php echo e($details['otp']); ?></b> </p>
    <p>thank you</p>
</body>
</html>
<?php /**PATH C:\projects\vendor-l\resources\views/mail/otp.blade.php ENDPATH**/ ?>