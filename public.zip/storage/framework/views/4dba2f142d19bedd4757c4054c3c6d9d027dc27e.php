<?php $__env->startSection('content'); ?>

<style>.fe{
 display: none;
}
.card-title:link{
    color: #898989
}
</style>
<div class="top-content section-container" style="width: 120%;margin-left:-15%;margin-top:-20px" id="img-hh">
    <div class="container-fluid">
            <div class="col col-md-10 offset-md-1 col-lg-8 offset-lg-2">
                <h1 class="wow fadeIn"><?php echo e(Session::get('utitle')); ?><?php if(Session::get('section')!=""): ?>
                    ,<?php echo e(Session::get('section')); ?>

                <?php endif; ?></h1>
                <div class="buttons wow fadeInUp">
                    <a class="btn btn-primary btn-customized" href="/#charts" role="button">
                        <i class="fa fa-area-chart" aria-hidden="true"></i> See Chart of visitors
                    </a>
                    <a class="btn btn-primary btn-customized-2" href="/#table" role="button">
                        <i class="fas fa-table"></i> Visitors Record
                    </a>
                </div>
            </div>
        </div>
</div>

            <!-- Section 1 -->
<div class="section-1-container section-container">
	<div class="container">
		<div class="row">
			<div class="col section-1 section-description wow fadeIn">
			  <h2>Keep The Track</h2>
			  <div class="divider-1 wow fadeInUp"><span></span></div>
			</div>
		</div>
    <div id="v1" class="row">
                  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                  <div class="col-sm-3">
                    <div class="card text-right" style="width: 90%;margin-left:5%">
                        <div class="card-body">
                          <h5 class="card-title">Today Visitors</h5>
                          <button class="btn btn-primary" disabled><?php echo e($v["tV"]); ?></button>
                        </div>
                      </div>
                  </div>
                  <div class="col-sm-3">
                      <div class="card text-right" style="width: 90%;margin-left:5%">
                          <div class="card-body">
                            <h5 class="card-title">Last 7 days' visitors</h5>
                            <button class="btn btn-primary" disabled><?php echo e($v["wV"]); ?></button>
                          </div>
                        </div>
                  </div>
                  <div class="col-sm-3">
                      <div class="card text-right" style="width: 90%;margin-left:5%">
                          <div class="card-body">
                            <h5 class="card-title">Last 30 days' visitors</h5>
                            <button class="btn btn-primary" disabled><?php echo e($v["mV"]); ?></button>
                          </div>
                        </div>
                  </div>
                  <div class="col-sm-3">
                      <div class="card text-right" style="width: 90%;margin-left:5%">
                          <div class="card-body">
                            <h5 class="card-title">Total visitors</h5>
                            <button class="btn btn-primary" disabled><?php echo e($v["V"]); ?></button>
                          </div>
                        </div>
                  </div>
                  <?php if(Session::get('section_id')==0): ?>
                  <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-sm-3" style="margin-top:20px">
                    <a href="/section?name=<?php echo e($sec->name); ?>">
                    <div class="card text-right" style="width: 90%;margin-left:5%;color:#898989">
                        <div class="card-body">
                          <h5 class="card-title">Today Visitors in <?php echo e($sec->name); ?></h5>
                          <button class="btn btn-primary" disabled><?php echo e($sec->tV); ?></button>
                        </div>
                      </div>
                    </a>
                  </div>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-sm-12" id="charts">
                    <div id="chart_combo" style="width: 120%;margin-left:-15%; height: 500px;"></div>
                  </div>
                  <script>
                    //Charts
                      google.charts.load('current', {'packages':['corechart']});
                          google.charts.setOnLoadCallback(drawChart);

                          function drawChart() {
                            var jsonData = $.ajax({
                                url: "/chart-data",
                                dataType: "array",
                                async: false
                                }).responseText;

                            // Create our data table out of JSON data loaded from server.
                            // var combo = new google.visualization.DataTable(jsonData);
                            var combo = google.visualization.arrayToDataTable([
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                [
                                    <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(is_numeric($d)): ?>
                                    <?php echo e($d); ?>,
                                    <?php else: ?>
                                    "<?php echo e($d); ?>",
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ],
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                            );

                            options = {
                              title : 'Area wise visit of Week',
                              vAxis: {title: 'Visitors'},
                              hAxis: {title: 'Date'},
                              seriesType: 'bars',
                            };
                            chart = new google.visualization.ComboChart(document.getElementById('chart_combo'));
                            chart.draw(combo, options);
                          }
                    </script>

                  <?php endif; ?>
    </div>
	</div>
</div>
<?php echo $__env->make('record_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent("profile"); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\vendor-l\resources\views/index.blade.php ENDPATH**/ ?>