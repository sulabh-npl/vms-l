<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4">
      <img src="/assets/ico/favicon-2.png" style="margin-top: 10%;" alt="">
    </div>
    <div class="col-sm-8" style="display: flex;align-items:flex-start; flex-direction: column;">
      <h2><?php echo e(Session::get('utitle')); ?></h2>
      <h4><strong>Expires At:</strong> <?php echo e($d->exp_date); ?></h4>
      <p><strong>Email  :</strong> <?php echo e($d->email); ?></p>
      <p><strong>Phone  :</strong> <?php echo e($d->phone); ?></p>
      <p><strong>Address:</strong> <?php echo e($d->address); ?></p>
    </div>
  </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\vendor-l\resources\views/self.blade.php ENDPATH**/ ?>