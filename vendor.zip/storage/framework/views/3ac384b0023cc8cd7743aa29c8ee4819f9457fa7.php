<?php $__env->startSection('content'); ?>
                <h2>Visitors Record</h2>

                <div class="row" style="width:110% ">
                    <table id="myTable" style="width: 105%;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                
                                <th>Designated Area</th>
                                
                                <th>Entry Time</th>
                                <th>Exit Time</th>
                                
                                
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i->name); ?></td>
                                <td><?php echo e($i->email); ?></td>
                                <td><?php echo e($i->phone); ?></td>
                                <td><?php echo e($i->section_name); ?></td>
                                <td><?php echo e($i->entry_time); ?></td>
                                <td><?php echo e($i->exit_time); ?></td>
                                <td><?php echo e($i->date); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
            <script>
                $(document).ready( function () {
                  $('#myTable').DataTable({
                      order:[[ 6, "desc" ]]
                  });
                } );
            </script>

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\vendor-l\resources\views/attendence.blade.php ENDPATH**/ ?>